<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* post/index.html.twig */
class __TwigTemplate_26305b5817a9715f1a859b1b098dd42cc50e4f8834988a97b7e816edf8a3525d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "post/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "post/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 3
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 3, $this->source); })()), "flashes", [0 => "success"], "method", false, false, false, 3));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 4
            echo "\t<div class=\"alert alert-success\">
\t\t";
            // line 5
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
\t</div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 8
        echo "<h2>List of all posts</h2>
<table class=\"table table-striped\">
\t<thead>
\t\t<tr>
\t\t\t<td>ID</td>
\t\t\t<td>name</td>
\t\t\t<td>datetime</td>
\t\t\t<td>description</td>
\t\t\t<td>image</td>
\t\t\t<td>capacity</td>
\t\t\t<td>email</td>
\t\t\t<td>phone</td>
\t\t\t<td>address</td>
\t\t\t<td>url</td>
\t\t\t<td>action</td>
\t\t</tr>
\t</thead>
\t<tbody>
\t\t";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new RuntimeError('Variable "posts" does not exist.', 26, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 27
            echo "\t\t\t<tr>
\t\t\t\t<td>";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "id", [], "any", false, false, false, 28), "html", null, true);
            echo "</td>
\t\t\t\t<td><a href=";
            // line 29
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("post.show", ["id" => twig_get_attribute($this->env, $this->source, $context["post"], "id", [], "any", false, false, false, 29)]), "html", null, true);
            echo ">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "name", [], "any", false, false, false, 29), "html", null, true);
            echo "</a></td>
\t\t\t\t<td>";
            // line 30
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "datetime", [], "any", false, false, false, 30), "Y-m-d H:i:s"), "html", null, true);
            echo "</td>
\t\t\t\t<td>";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "description", [], "any", false, false, false, 31), "html", null, true);
            echo "</td>
\t\t\t\t<td><img src=\"";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "image", [], "any", false, false, false, 32), "html", null, true);
            echo "\" /></td></td>
\t\t\t\t<td>";
            // line 33
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "capacity", [], "any", false, false, false, 33), "html", null, true);
            echo "</td>
\t\t\t\t<td>";
            // line 34
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "email", [], "any", false, false, false, 34), "html", null, true);
            echo "</td>
\t\t\t\t<td>";
            // line 35
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "phone", [], "any", false, false, false, 35), "html", null, true);
            echo "</td>
\t\t\t\t<td>";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "address", [], "any", false, false, false, 36), "html", null, true);
            echo "</td>
\t\t\t\t<td>";
            // line 37
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "url", [], "any", false, false, false, 37), "html", null, true);
            echo "</td>
\t\t\t\t<td><a href=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("post.delete", ["id" => twig_get_attribute($this->env, $this->source, $context["post"], "id", [], "any", false, false, false, 38)]), "html", null, true);
            echo "\">delete</a></td>
\t\t\t\t



\t\t\t</tr>
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "\t</tbody>
</table>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "post/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  157 => 45,  144 => 38,  140 => 37,  136 => 36,  132 => 35,  128 => 34,  124 => 33,  120 => 32,  116 => 31,  112 => 30,  106 => 29,  102 => 28,  99 => 27,  95 => 26,  75 => 8,  66 => 5,  63 => 4,  59 => 3,  52 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends('base.html.twig') %}
{% block body %}
{% for message in app.flashes('success') %}
\t<div class=\"alert alert-success\">
\t\t{{ message }}
\t</div>
{% endfor %}
<h2>List of all posts</h2>
<table class=\"table table-striped\">
\t<thead>
\t\t<tr>
\t\t\t<td>ID</td>
\t\t\t<td>name</td>
\t\t\t<td>datetime</td>
\t\t\t<td>description</td>
\t\t\t<td>image</td>
\t\t\t<td>capacity</td>
\t\t\t<td>email</td>
\t\t\t<td>phone</td>
\t\t\t<td>address</td>
\t\t\t<td>url</td>
\t\t\t<td>action</td>
\t\t</tr>
\t</thead>
\t<tbody>
\t\t{% for post in posts %}
\t\t\t<tr>
\t\t\t\t<td>{{ post.id }}</td>
\t\t\t\t<td><a href={{ path('post.show', {id: post.id}) }}>{{ post.name }}</a></td>
\t\t\t\t<td>{{ post.datetime|date('Y-m-d H:i:s') }}</td>
\t\t\t\t<td>{{ post.description }}</td>
\t\t\t\t<td><img src=\"{{ post.image }}\" /></td></td>
\t\t\t\t<td>{{ post.capacity }}</td>
\t\t\t\t<td>{{ post.email }}</td>
\t\t\t\t<td>{{ post.phone }}</td>
\t\t\t\t<td>{{ post.address }}</td>
\t\t\t\t<td>{{ post.url }}</td>
\t\t\t\t<td><a href=\"{{ path('post.delete', {id: post.id}) }}\">delete</a></td>
\t\t\t\t



\t\t\t</tr>
\t\t{% endfor %}
\t</tbody>
</table>
{% endblock %}", "post/index.html.twig", "/Applications/XAMPP/xamppfiles/htdocs/Events/templates/post/index.html.twig");
    }
}
